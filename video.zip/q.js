// 1) как скажется на верстке центр макета:
// [center-start] repeat(8, [col-start] minmax(min-content, 14rem) [col-end]) [center-end] minmax(6rem, 1fr) [center-end]

// 2) нужно ли где-то задать ширину?
// 3) Если в грид макете у меня был sidebar = 8 rem, а в этом макете нету, то нужно ли раскидать эти 8 rem на колонки или buffer?

// добавить h1