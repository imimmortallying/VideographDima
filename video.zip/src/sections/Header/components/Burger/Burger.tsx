import cls from "./Burger.module.sass";
import Logo from "../../../../assets/logo.png";
interface BurgerProps {
  className?: string;
}

function Burger({}: BurgerProps) {
  return (
    <nav className={cls.navbar}>
      <a href="#" className={cls.logo}>
      <img src={Logo} className={cls.logo}></img>
      </a>
      <ul className={cls.nav_links}>
        <li>
          <a href="#">Home</a>
        </li>
        <li>
          <a href="#">About</a>
        </li>
        <li>
          <a href="#">Gallery</a>
        </li>
        <li>
          <a href="#">Contact</a>
        </li>
      </ul>
        <i  id="burger"></i>
    </nav>
  );
}

export default Burger;
